import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { Label } from '@/components/ui/label';

interface MobileFormFieldProps {
  label: string;
  children: ReactNode;
  error?: string;
  required?: boolean;
  hint?: string;
  className?: string;
}

export function MobileFormField({ 
  label, 
  children, 
  error, 
  required,
  hint,
  className 
}: MobileFormFieldProps) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label className="text-sm sm:text-base font-medium">
        {label}
        {required && <span className="text-destructive ml-1">*</span>}
      </Label>
      {children}
      {hint && !error && (
        <p className="text-xs sm:text-sm text-muted-foreground">{hint}</p>
      )}
      {error && (
        <p className="text-xs sm:text-sm text-destructive font-medium">{error}</p>
      )}
    </div>
  );
}

interface MobileFormProps {
  children: ReactNode;
  onSubmit?: (e: React.FormEvent) => void;
  className?: string;
}

export function MobileForm({ children, onSubmit, className }: MobileFormProps) {
  return (
    <form 
      onSubmit={onSubmit} 
      className={cn("space-y-4 sm:space-y-6", className)}
    >
      {children}
    </form>
  );
}

interface MobileFormActionsProps {
  children: ReactNode;
  className?: string;
}

export function MobileFormActions({ children, className }: MobileFormActionsProps) {
  return (
    <div className={cn(
      "flex flex-col sm:flex-row gap-2 sm:gap-3",
      "pt-4 sm:pt-6",
      "sticky bottom-0 left-0 right-0",
      "bg-background/95 backdrop-blur-sm",
      "p-4 sm:p-0",
      "-mx-4 sm:mx-0",
      "border-t sm:border-t-0",
      "z-10",
      className
    )}>
      {children}
    </div>
  );
}
