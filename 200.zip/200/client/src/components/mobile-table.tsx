import { ReactNode } from 'react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface MobileTableProps {
  data: any[];
  columns: {
    key: string;
    label: string;
    render?: (item: any) => ReactNode;
    className?: string;
  }[];
  renderCard?: (item: any, index: number) => ReactNode;
  emptyMessage?: string;
  className?: string;
}

export function MobileTable({ 
  data, 
  columns, 
  renderCard, 
  emptyMessage = "Nenhum item encontrado",
  className 
}: MobileTableProps) {
  if (data.length === 0) {
    return (
      <Card className="p-8 text-center text-muted-foreground">
        {emptyMessage}
      </Card>
    );
  }

  return (
    <>
      {/* Mobile View - Cards */}
      <div className="md:hidden space-y-3">
        {data.map((item, index) => (
          renderCard ? (
            renderCard(item, index)
          ) : (
            <Card key={index} className="p-4 space-y-2">
              {columns.map((col) => (
                <div key={col.key} className="flex justify-between items-center gap-4 py-1">
                  <span className="text-sm font-medium text-muted-foreground min-w-[100px]">
                    {col.label}:
                  </span>
                  <span className={cn("text-sm font-semibold text-right flex-1", col.className)}>
                    {col.render ? col.render(item) : item[col.key]}
                  </span>
                </div>
              ))}
            </Card>
          )
        ))}
      </div>

      {/* Desktop View - Table */}
      <div className="hidden md:block overflow-x-auto rounded-lg border">
        <table className={cn("w-full text-sm", className)}>
          <thead className="bg-muted/50">
            <tr>
              {columns.map((col) => (
                <th key={col.key} className="text-left p-3 font-semibold">
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y">
            {data.map((item, index) => (
              <tr key={index} className="hover:bg-muted/30 transition-colors">
                {columns.map((col) => (
                  <td key={col.key} className={cn("p-3", col.className)}>
                    {col.render ? col.render(item) : item[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
