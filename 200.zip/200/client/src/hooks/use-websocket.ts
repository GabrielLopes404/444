import { useEffect, useRef, useState, useCallback } from 'react';
import { useToast } from './use-toast';

interface NotificationMessage {
  type: 'notification' | 'alert' | 'update';
  title: string;
  message: string;
  severity?: 'info' | 'warning' | 'error' | 'success';
  data?: any;
  timestamp: Date;
}

export function useWebSocket() {
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const { toast } = useToast();
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      console.log('WebSocket: Sem token, aguardando login');
      return;
    }

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      
      if (!host || host === 'localhost:undefined') {
        console.log('WebSocket: Host inválido, aguardando...');
        return;
      }
      
      const wsUrl = `${protocol}//${host}/ws?token=${token}`;
      console.log('WebSocket: Conectando em', wsUrl);

      const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setIsConnected(true);
      console.log('WebSocket conectado');
    };

    ws.onmessage = (event) => {
      try {
        const notification: NotificationMessage = JSON.parse(event.data);
        
        const variant = 
          notification.severity === 'error' ? 'destructive' :
          notification.severity === 'success' ? 'default' :
          notification.severity === 'warning' ? 'default' :
          'default';

        toast({
          title: notification.title,
          description: notification.message,
          variant,
        });
      } catch (error) {
        console.error('Erro ao processar notificação:', error);
      }
    };

    ws.onerror = (error) => {
      console.log('WebSocket: Erro de conexão (normal se não estiver logado)');
    };

    ws.onclose = () => {
      setIsConnected(false);
      console.log('WebSocket desconectado');
      
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 5000);
    };

      wsRef.current = ws;
    } catch (error) {
      console.log('WebSocket: Erro ao criar conexão', error);
    }
  }, [toast]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return { isConnected };
}
