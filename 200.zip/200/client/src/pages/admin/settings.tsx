import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Shield, Bell, Database, Palette, Globe } from "lucide-react";
import { pageVariants, staggerContainer, fadeInUp, headerVariants, buttonHover } from "@/lib/animations";

export default function AdminSettings() {
  return (
    <motion.div 
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="flex-1 space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
    >
      <motion.div variants={headerVariants} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
            Configurações do Sistema
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            Gerencie as configurações gerais do sistema
          </p>
        </div>
      </motion.div>

      <motion.div className="grid gap-3 sm:gap-4 md:gap-6" variants={staggerContainer}>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-base sm:text-lg md:text-xl">Segurança</CardTitle>
              </div>
              <CardDescription className="text-xs sm:text-sm">
                Configure as opções de segurança e autenticação
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Autenticação de Dois Fatores</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Exigir 2FA para todos os administradores
                  </p>
                </div>
                <Switch />
              </div>
              <Separator />
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Expiração de Sessão</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Tempo limite de inatividade (em minutos)
                  </p>
                </div>
                <Input type="number" defaultValue="30" className="w-full sm:w-24" />
              </div>
              <Separator />
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Política de Senhas Fortes</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Exigir senhas complexas (min. 8 caracteres)
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Bell className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-base sm:text-lg md:text-xl">Notificações</CardTitle>
              </div>
              <CardDescription className="text-xs sm:text-sm">
                Configure as notificações do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Notificações por Email</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Enviar alertas importantes por email
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Alertas de Segurança</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Notificar sobre tentativas de acesso suspeitas
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Relatórios Diários</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Receber resumo diário de atividades
                  </p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Database className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-base sm:text-lg md:text-xl">Banco de Dados</CardTitle>
              </div>
              <CardDescription className="text-xs sm:text-sm">
                Opções de backup e manutenção
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Backup Automático</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Realizar backup diário automaticamente
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="space-y-2">
                <Label className="text-sm sm:text-base">Último Backup</Label>
                <p className="text-xs sm:text-sm text-muted-foreground">
                  02/11/2024 às 22:00
                </p>
                <Button variant="outline" size="sm" className="w-full sm:w-auto">
                  Fazer Backup Agora
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Palette className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-base sm:text-lg md:text-xl">Aparência</CardTitle>
              </div>
              <CardDescription className="text-xs sm:text-sm">
                Personalize a aparência do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4">
              <div className="space-y-2">
                <Label className="text-sm sm:text-base">Cor Primária</Label>
                <div className="flex gap-2">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-primary border-2 border-primary cursor-pointer" />
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-blue-500 border-2 border-transparent hover:border-primary cursor-pointer" />
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-green-500 border-2 border-transparent hover:border-primary cursor-pointer" />
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-purple-500 border-2 border-transparent hover:border-primary cursor-pointer" />
                </div>
              </div>
              <Separator />
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                <div className="space-y-0.5">
                  <Label className="text-sm sm:text-base">Modo Escuro Padrão</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Usar tema escuro como padrão
                  </p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Globe className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-base sm:text-lg md:text-xl">Localização e Idioma</CardTitle>
              </div>
              <CardDescription className="text-xs sm:text-sm">
                Configure o idioma e fuso horário
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4">
              <div className="space-y-2">
                <Label className="text-sm sm:text-base">Idioma do Sistema</Label>
                <Input defaultValue="Português (Brasil)" disabled className="text-xs sm:text-sm" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm sm:text-base">Fuso Horário</Label>
                <Input defaultValue="America/Sao_Paulo (GMT-3)" disabled className="text-xs sm:text-sm" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={fadeInUp} className="flex justify-end">
          <motion.div variants={buttonHover} whileHover="hover" whileTap="tap">
            <Button size="lg" className="w-full sm:w-auto shadow-lg hover:shadow-xl">
              Salvar Todas as Configurações
            </Button>
          </motion.div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
