import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, MessageSquare, Ticket as TicketIcon, Clock, CheckCircle2, XCircle, AlertCircle, Tag } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function AdminTickets() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateCategoryOpen, setIsCreateCategoryOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [isTicketDetailsOpen, setIsTicketDetailsOpen] = useState(false);
  const [replyMessage, setReplyMessage] = useState("");

  const { data: tickets = [] } = useQuery({
    queryKey: ["/api/tickets/admin/all"],
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/tickets/categories"],
  });

  const { data: messages = [] } = useQuery({
    queryKey: [`/api/tickets/${selectedTicket?.id}/messages`],
    enabled: !!selectedTicket,
  });

  const createCategoryMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/tickets/admin/categories", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/categories"] });
      setIsCreateCategoryOpen(false);
      toast({ title: "Categoria criada com sucesso!" });
    },
  });

  const updateTicketMutation = useMutation({
    mutationFn: ({ id, data }: any) => apiRequest("PUT", `/api/tickets/admin/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/admin/all"] });
      toast({ title: "Ticket atualizado com sucesso!" });
    },
  });

  const closeTicketMutation = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/tickets/admin/${id}/close`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/admin/all"] });
      setIsTicketDetailsOpen(false);
      toast({ title: "Ticket fechado com sucesso!" });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", `/api/tickets/${selectedTicket.id}/messages`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tickets/${selectedTicket.id}/messages`] });
      setReplyMessage("");
      toast({ title: "Resposta enviada com sucesso!" });
    },
  });

  const handleCreateCategory = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createCategoryMutation.mutate({
      name: formData.get("name"),
      description: formData.get("description"),
      color: formData.get("color"),
    });
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage.trim()) return;
    sendMessageMutation.mutate({
      message: replyMessage,
      isInternal: false,
    });
  };

  const handleUpdateStatus = (ticketId: string, status: string) => {
    updateTicketMutation.mutate({ id: ticketId, data: { status } });
  };

  const handleUpdatePriority = (ticketId: string, priority: string) => {
    updateTicketMutation.mutate({ id: ticketId, data: { priority } });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "in_progress": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "closed": return "bg-green-500/10 text-green-500 border-green-500/20";
      default: return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "low": return "bg-gray-500/10 text-gray-500 border-gray-500/20";
      case "medium": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "high": return "bg-red-500/10 text-red-500 border-red-500/20";
      default: return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      open: "Aberto",
      in_progress: "Em Andamento",
      closed: "Fechado",
    };
    return labels[status] || status;
  };

  const getPriorityLabel = (priority: string) => {
    const labels: Record<string, string> = {
      low: "Baixa",
      medium: "Média",
      high: "Alta",
    };
    return labels[priority] || priority;
  };

  const openTickets = tickets.filter((t: any) => t.status === "open").length;
  const inProgressTickets = tickets.filter((t: any) => t.status === "in_progress").length;
  const closedTickets = tickets.filter((t: any) => t.status === "closed").length;

  return (
    <div className="flex-1 space-y-6 p-6 bg-gradient-to-br from-background via-background to-primary/5">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
          Gerenciamento de Tickets
        </h1>
        <p className="text-muted-foreground mt-2">
          Gerencie tickets de suporte e categorias
        </p>
      </motion.div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-2 border-blue-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Tickets Abertos</CardTitle>
            <AlertCircle className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{openTickets}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-yellow-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Em Andamento</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inProgressTickets}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Fechados</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{closedTickets}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total de Tickets</CardTitle>
            <TicketIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tickets.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-2 border-primary/10">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Categorias de Tickets</CardTitle>
          <Dialog open={isCreateCategoryOpen} onOpenChange={setIsCreateCategoryOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Nova Categoria
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Nova Categoria</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateCategory} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome da Categoria</Label>
                  <Input id="name" name="name" required />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea id="description" name="description" />
                </div>
                <div>
                  <Label htmlFor="color">Cor</Label>
                  <Input id="color" name="color" type="color" defaultValue="#3b82f6" />
                </div>
                <Button type="submit" className="w-full">Criar Categoria</Button>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {categories.map((category: any) => (
              <Badge key={category.id} variant="outline" className="gap-2">
                <Tag className="h-3 w-3" style={{ color: category.color }} />
                {category.name}
              </Badge>
            ))}
            {categories.length === 0 && (
              <p className="text-sm text-muted-foreground">Nenhuma categoria cadastrada</p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-primary/10">
        <CardHeader>
          <CardTitle>Todos os Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {tickets.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Nenhum ticket encontrado</p>
            ) : (
              tickets.map((ticket: any) => {
                const category = categories.find((c: any) => c.id === ticket.categoryId);
                return (
                  <div
                    key={ticket.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedTicket(ticket);
                      setIsTicketDetailsOpen(true);
                    }}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium">{ticket.subject}</p>
                        {category && (
                          <Badge variant="outline" className="text-xs">
                            <Tag className="h-3 w-3 mr-1" style={{ color: category.color }} />
                            {category.name}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1">{ticket.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Criado em {format(new Date(ticket.createdAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                        {getPriorityLabel(ticket.priority)}
                      </Badge>
                      <Badge variant="outline" className={getStatusColor(ticket.status)}>
                        {getStatusLabel(ticket.status)}
                      </Badge>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isTicketDetailsOpen} onOpenChange={setIsTicketDetailsOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          {selectedTicket && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selectedTicket.subject}</DialogTitle>
                <div className="flex gap-2 mt-2">
                  <Badge variant="outline" className={getStatusColor(selectedTicket.status)}>
                    {getStatusLabel(selectedTicket.status)}
                  </Badge>
                  <Badge variant="outline" className={getPriorityColor(selectedTicket.priority)}>
                    {getPriorityLabel(selectedTicket.priority)}
                  </Badge>
                </div>
              </DialogHeader>

              <div className="space-y-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <p className="text-sm font-medium mb-2">Descrição:</p>
                  <p className="text-sm">{selectedTicket.description}</p>
                </div>

                <div className="flex gap-2">
                  <div className="flex-1">
                    <Label>Status</Label>
                    <select
                      value={selectedTicket.status}
                      onChange={(e) => handleUpdateStatus(selectedTicket.id, e.target.value)}
                      className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
                    >
                      <option value="open">Aberto</option>
                      <option value="in_progress">Em Andamento</option>
                      <option value="closed">Fechado</option>
                    </select>
                  </div>
                  <div className="flex-1">
                    <Label>Prioridade</Label>
                    <select
                      value={selectedTicket.priority}
                      onChange={(e) => handleUpdatePriority(selectedTicket.id, e.target.value)}
                      className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
                    >
                      <option value="low">Baixa</option>
                      <option value="medium">Média</option>
                      <option value="high">Alta</option>
                    </select>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    Mensagens
                  </h3>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {messages.map((msg: any) => (
                      <div key={msg.id} className="p-3 bg-muted/20 rounded-lg">
                        <p className="text-sm">{msg.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(msg.createdAt), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedTicket.status !== "closed" && (
                  <form onSubmit={handleSendReply} className="space-y-3">
                    <Textarea
                      placeholder="Digite sua resposta..."
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      rows={4}
                    />
                    <div className="flex gap-2 justify-end">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => closeTicketMutation.mutate(selectedTicket.id)}
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Fechar Ticket
                      </Button>
                      <Button type="submit">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Enviar Resposta
                      </Button>
                    </div>
                  </form>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
