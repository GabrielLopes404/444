import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Users, DollarSign, Calendar } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function AdminSubscriptions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreatePlanOpen, setIsCreatePlanOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any>(null);

  const { data: plans = [] } = useQuery({
    queryKey: ["/api/subscriptions/plans"],
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ["/api/subscriptions/admin/all"],
  });

  const createPlanMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/subscriptions/admin/plans", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions/plans"] });
      setIsCreatePlanOpen(false);
      toast({ title: "Plano criado com sucesso!" });
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: ({ id, data }: any) => apiRequest("PUT", `/api/subscriptions/admin/plans/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions/plans"] });
      setEditingPlan(null);
      toast({ title: "Plano atualizado com sucesso!" });
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/subscriptions/admin/plans/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions/plans"] });
      toast({ title: "Plano excluído com sucesso!" });
    },
  });

  const handleCreatePlan = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createPlanMutation.mutate({
      name: formData.get("name"),
      description: formData.get("description"),
      price: parseFloat(formData.get("price") as string),
      billingPeriod: formData.get("billingPeriod"),
      maxUsers: parseInt(formData.get("maxUsers") as string) || null,
      maxInvoices: parseInt(formData.get("maxInvoices") as string) || null,
      maxContacts: parseInt(formData.get("maxContacts") as string) || null,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-500/10 text-green-500 border-green-500/20";
      case "canceled": return "bg-red-500/10 text-red-500 border-red-500/20";
      case "expired": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      default: return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      active: "Ativa",
      canceled: "Cancelada",
      expired: "Expirada",
      trial: "Trial",
    };
    return labels[status] || status;
  };

  const activeSubscriptions = subscriptions.filter((s: any) => s.status === "active").length;
  const totalRevenue = subscriptions
    .filter((s: any) => s.status === "active")
    .reduce((sum: number, s: any) => {
      const plan = plans.find((p: any) => p.id === s.planId);
      return sum + (plan ? parseFloat(plan.price) : 0);
    }, 0);

  return (
    <div className="flex-1 space-y-6 p-6 bg-gradient-to-br from-background via-background to-primary/5">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
          Gerenciamento de Assinaturas
        </h1>
        <p className="text-muted-foreground mt-2">
          Gerencie planos, assinaturas e pagamentos
        </p>
      </motion.div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-2 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Assinaturas Ativas</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeSubscriptions}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-chart-2/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Receita Mensal</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totalRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-chart-4/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total de Planos</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{plans.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-2 border-primary/10">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Planos Disponíveis</CardTitle>
          <Dialog open={isCreatePlanOpen} onOpenChange={setIsCreatePlanOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Novo Plano
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Criar Novo Plano</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreatePlan} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome do Plano</Label>
                  <Input id="name" name="name" required />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea id="description" name="description" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="price">Preço (R$)</Label>
                    <Input id="price" name="price" type="number" step="0.01" required />
                  </div>
                  <div>
                    <Label htmlFor="billingPeriod">Período de Cobrança</Label>
                    <select id="billingPeriod" name="billingPeriod" className="w-full rounded-md border border-input bg-background px-3 py-2">
                      <option value="monthly">Mensal</option>
                      <option value="yearly">Anual</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="maxUsers">Máx. Usuários</Label>
                    <Input id="maxUsers" name="maxUsers" type="number" />
                  </div>
                  <div>
                    <Label htmlFor="maxInvoices">Máx. Faturas</Label>
                    <Input id="maxInvoices" name="maxInvoices" type="number" />
                  </div>
                  <div>
                    <Label htmlFor="maxContacts">Máx. Contatos</Label>
                    <Input id="maxContacts" name="maxContacts" type="number" />
                  </div>
                </div>
                <Button type="submit" className="w-full">Criar Plano</Button>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {plans.map((plan: any) => (
              <Card key={plan.id} className="border-2 hover:border-primary/30 transition-colors">
                <CardHeader>
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-3xl font-bold">
                    R$ {parseFloat(plan.price).toFixed(2)}
                    <span className="text-sm font-normal text-muted-foreground">
                      /{plan.billingPeriod === "monthly" ? "mês" : "ano"}
                    </span>
                  </div>
                  <div className="space-y-1 text-sm">
                    {plan.maxUsers && <p>• Até {plan.maxUsers} usuários</p>}
                    {plan.maxInvoices && <p>• Até {plan.maxInvoices} faturas</p>}
                    {plan.maxContacts && <p>• Até {plan.maxContacts} contatos</p>}
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => setEditingPlan(plan)}>
                      <Edit className="h-3 w-3 mr-1" />
                      Editar
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => {
                        if (confirm("Deseja realmente excluir este plano?")) {
                          deletePlanMutation.mutate(plan.id);
                        }
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-primary/10">
        <CardHeader>
          <CardTitle>Assinaturas Ativas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {subscriptions.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Nenhuma assinatura encontrada</p>
            ) : (
              subscriptions.map((sub: any) => {
                const plan = plans.find((p: any) => p.id === sub.planId);
                return (
                  <div key={sub.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors">
                    <div className="flex-1">
                      <p className="font-medium">Cliente ID: {sub.userId.substring(0, 8)}...</p>
                      <p className="text-sm text-muted-foreground">Plano: {plan?.name || "N/A"}</p>
                    </div>
                    <div className="text-right mr-4">
                      <p className="font-mono font-semibold">R$ {plan ? parseFloat(plan.price).toFixed(2) : "0.00"}</p>
                      <p className="text-xs text-muted-foreground">
                        Início: {new Date(sub.startDate).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <Badge variant="outline" className={getStatusColor(sub.status)}>
                      {getStatusLabel(sub.status)}
                    </Badge>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
