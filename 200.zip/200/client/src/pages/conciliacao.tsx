import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, CheckCircle2, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { pageVariants, staggerContainer, fadeInUp, headerVariants, buttonHover } from "@/lib/animations";

const extratoImportado = [
  { id: 1, data: "2024-11-01", descricao: "PIX RECEBIDO - JOAO SILVA", valor: 5200, conciliado: true },
  { id: 2, data: "2024-11-01", descricao: "TED ENVIADA - ABC FORNEC", valor: -2800, conciliado: true },
  { id: 3, data: "2024-10-31", descricao: "PIX RECEBIDO - MARIA SANTOS", valor: 3500, conciliado: false },
  { id: 4, data: "2024-10-30", descricao: "BOLETO PAGTO - ALUGUEL", valor: -4200, conciliado: true },
];

const lancamentosSistema = [
  { id: 1, data: "2024-11-01", descricao: "Pagamento Cliente ABC", valor: 5200, conciliado: true },
  { id: 2, data: "2024-11-01", descricao: "Fornecedor XYZ Ltda", valor: -2800, conciliado: true },
  { id: 3, data: "2024-10-30", descricao: "Aluguel Escritório", valor: -4200, conciliado: true },
  { id: 4, data: "2024-10-25", descricao: "Serviço Consultoria", valor: 1800, conciliado: false },
];

export default function Conciliacao() {
  return (
    <motion.div 
      className="flex-1 space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.div 
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        variants={headerVariants}
      >
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
            Conciliação Bancária
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">Importe extratos e reconcilie lançamentos</p>
        </div>
      </motion.div>

      <motion.div variants={fadeInUp}>
        <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Importar Extrato OFX</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-6 sm:p-8 md:p-12 hover:border-primary/50 transition-colors">
            <Upload className="h-8 w-8 sm:h-10 sm:w-10 md:h-12 md:w-12 text-muted-foreground mb-3 sm:mb-4" />
            <h3 className="text-base sm:text-lg font-semibold mb-1 sm:mb-2 text-center">Arraste um arquivo OFX aqui</h3>
            <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4">ou clique para selecionar</p>
            <Input
              type="file"
              accept=".ofx"
              className="hidden"
              id="file-upload"
              data-testid="input-file-upload"
            />
            <motion.div variants={buttonHover} whileHover="hover" whileTap="tap">
              <Button asChild data-testid="button-upload-ofx" className="shadow-md hover:shadow-lg transition-shadow">
                <label htmlFor="file-upload" className="cursor-pointer">
                  <span className="hidden xs:inline">Selecionar Arquivo</span>
                  <span className="xs:hidden">Selecionar</span>
                </label>
              </Button>
            </motion.div>
          </div>
        </CardContent>
      </Card>
      </motion.div>

      <motion.div 
        className="grid gap-3 sm:gap-4 md:gap-6 grid-cols-1 sm:grid-cols-3"
        variants={staggerContainer}
      >
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-success/10 hover:border-success/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Total Conciliado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold text-success">R$ 12.200,00</div>
              <p className="text-xs text-muted-foreground mt-1">
                3 de 4 transações
              </p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-warning/10 hover:border-warning/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Pendente de Conciliação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold text-warning">R$ 5.300,00</div>
              <p className="text-xs text-muted-foreground mt-1">
                2 transações
              </p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                Taxa de Conciliação
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">75%</div>
              <p className="text-xs text-muted-foreground mt-1">
                Meta: 95%
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid gap-3 sm:gap-4 md:gap-6 lg:grid-cols-2">
        <motion.div variants={fadeInUp}>
          <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Extrato Bancário Importado</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <div className="min-w-[600px]">
              <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {extratoImportado.map((item) => (
                  <TableRow key={item.id} data-testid={`extrato-row-${item.id}`}>
                    <TableCell className="font-mono text-sm">
                      {new Date(item.data).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {item.descricao}
                    </TableCell>
                    <TableCell className={`text-right font-mono font-semibold ${
                      item.valor > 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {item.valor > 0 ? '+' : ''}R$ {Math.abs(item.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      {item.conciliado ? (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Conciliado
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Pendente
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Lançamentos do Sistema</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lancamentosSistema.map((item) => (
                  <TableRow key={item.id} data-testid={`lancamento-row-${item.id}`}>
                    <TableCell className="font-mono text-sm">
                      {new Date(item.data).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {item.descricao}
                    </TableCell>
                    <TableCell className={`text-right font-mono font-semibold ${
                      item.valor > 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {item.valor > 0 ? '+' : ''}R$ {Math.abs(item.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      {item.conciliado ? (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Conciliado
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Pendente
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
