import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Mail, ArrowRight, Gem, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

export default function RecuperarSenhaNew() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
        credentials: "include",
      });

      const data = await response.json();

      if (response.ok) {
        setEmailSent(true);
        toast({
          title: "E-mail enviado!",
          description: "Verifique sua caixa de entrada para recuperar sua senha.",
        });
      } else {
        toast({
          title: "Erro",
          description: data.message || "Erro ao enviar e-mail de recuperação",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao conectar com o servidor",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />
      
      <motion.div
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-600/20 rounded-full blur-[120px]"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-slate-900/50 backdrop-blur-2xl border-2 border-white/10 rounded-3xl shadow-[0_20px_80px_-15px_rgba(139,92,246,0.5)] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-violet-600/10 via-transparent to-purple-600/10 pointer-events-none" />
          
          <div className="relative p-8 sm:p-10">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
              className="flex justify-center mb-6"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-violet-500 to-purple-600 rounded-3xl blur-2xl opacity-60 animate-pulse" />
                <div className="relative bg-gradient-to-br from-violet-600 to-purple-700 p-6 rounded-3xl shadow-2xl">
                  <Gem className="w-12 h-12 text-white" />
                </div>
              </div>
            </motion.div>

            <div className="text-center mb-8">
              <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-violet-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
                Recuperar Senha
              </h1>
              <p className="text-slate-400 text-sm sm:text-base">
                {emailSent
                  ? "Instruções enviadas para seu e-mail"
                  : "Digite seu e-mail para receber instruções"}
              </p>
            </div>

            {!emailSent ? (
              <form onSubmit={handleResetPassword} className="space-y-5">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail className="w-5 h-5 text-violet-400" />
                  </div>
                  <Input
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="pl-12 h-14 bg-slate-800/50 border-slate-700/50 focus:border-violet-500 focus:ring-violet-500/20 text-white placeholder:text-slate-500 rounded-2xl"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-14 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold rounded-2xl shadow-lg hover:shadow-violet-500/50 transition-all duration-300 group"
                >
                  {isLoading ? (
                    <span>Enviando...</span>
                  ) : (
                    <>
                      <span>ENVIAR INSTRUÇÕES</span>
                      <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Button>
              </form>
            ) : (
              <div className="space-y-6">
                <div className="bg-violet-500/10 border border-violet-500/20 rounded-2xl p-6 text-center">
                  <p className="text-slate-300 text-sm">
                    Enviamos um e-mail com instruções para <strong className="text-violet-400">{email}</strong>.
                    Verifique sua caixa de entrada e spam.
                  </p>
                </div>

                <Button
                  onClick={() => setEmailSent(false)}
                  variant="outline"
                  className="w-full h-12 border-2 border-slate-700 hover:border-violet-500 bg-transparent text-slate-300 rounded-xl"
                >
                  Tentar outro e-mail
                </Button>
              </div>
            )}

            <div className="mt-8 pt-6 border-t border-slate-800">
              <Link href="/login">
                <a className="flex items-center justify-center text-violet-400 hover:text-violet-300 text-sm font-medium transition-colors">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar para login
                </a>
              </Link>
            </div>
          </div>
        </div>

        <p className="text-center text-slate-600 text-xs mt-6">
          © 2024 Diamond System. Todos os direitos reservados.
        </p>
      </motion.div>
    </div>
  );
}
