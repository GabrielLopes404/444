import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { AdminSidebar } from "@/components/admin-sidebar";
import { DashboardHeader } from "@/components/dashboard-header";
import { useWebSocket } from "@/hooks/use-websocket";
import { lazy, Suspense } from "react";

const Landing = lazy(() => import("@/pages/landing"));
const Login = lazy(() => import("@/pages/login-new"));
const Registro = lazy(() => import("@/pages/registro"));
const RecuperarSenha = lazy(() => import("@/pages/recuperar-senha-new"));
const Dashboard = lazy(() => import("@/pages/dashboard"));
const Contas = lazy(() => import("@/pages/contas"));
const FluxoCaixa = lazy(() => import("@/pages/fluxo-caixa"));
const Contatos = lazy(() => import("@/pages/contatos"));
const Relatorios = lazy(() => import("@/pages/relatorios"));
const Conciliacao = lazy(() => import("@/pages/conciliacao"));
const Faturas = lazy(() => import("@/pages/faturas"));
const Configuracoes = lazy(() => import("@/pages/configuracoes"));
const AdminDashboard = lazy(() => import("@/pages/admin/dashboard"));
const AdminUsers = lazy(() => import("@/pages/admin/users"));
const AdminReports = lazy(() => import("@/pages/admin/reports"));
const AdminSettings = lazy(() => import("@/pages/admin/settings"));
const AdminSubscriptions = lazy(() => import("@/pages/admin/subscriptions"));
const AdminTickets = lazy(() => import("@/pages/admin/tickets"));
const Suporte = lazy(() => import("@/pages/suporte"));
const NotFound = lazy(() => import("@/pages/not-found"));

function LoadingFallback() {
  return (
    <div className="flex items-center justify-center h-screen w-full">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );
}

function AppRouter() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/login" component={Login} />
        <Route path="/registro" component={Registro} />
        <Route path="/recuperar-senha" component={RecuperarSenha} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/contas" component={Contas} />
        <Route path="/fluxo-caixa" component={FluxoCaixa} />
        <Route path="/conciliacao" component={Conciliacao} />
        <Route path="/faturas" component={Faturas} />
        <Route path="/contatos" component={Contatos} />
        <Route path="/relatorios" component={Relatorios} />
        <Route path="/configuracoes" component={Configuracoes} />
        <Route path="/suporte" component={Suporte} />
        <Route path="/admin/dashboard" component={AdminDashboard} />
        <Route path="/admin/users" component={AdminUsers} />
        <Route path="/admin/reports" component={AdminReports} />
        <Route path="/admin/settings" component={AdminSettings} />
        <Route path="/admin/subscriptions" component={AdminSubscriptions} />
        <Route path="/admin/tickets" component={AdminTickets} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function AppContent() {
  const [location] = useLocation();
  const isLandingPage = location === "/";
  const isLoginPage = location === "/login";
  const isRegistroPage = location === "/registro";
  const isRecuperarSenhaPage = location === "/recuperar-senha";
  const isAdminPage = location.startsWith("/admin");
  
  useWebSocket();

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  if (isLandingPage || isLoginPage || isRegistroPage || isRecuperarSenhaPage) {
    return <AppRouter />;
  }

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full max-w-full overflow-hidden">
        {isAdminPage ? <AdminSidebar /> : <AppSidebar />}
        <div className="flex flex-col flex-1 w-full max-w-full min-w-0 overflow-hidden">
          <DashboardHeader />
          <main className="flex-1 overflow-x-hidden overflow-y-auto w-full max-w-full mobile-safe-area">
            <div className="w-full max-w-full overflow-x-hidden">
              <AppRouter />
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
