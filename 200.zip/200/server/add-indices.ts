import { db } from './db';
import { sql } from 'drizzle-orm';

async function addIndices() {
  console.log('🔄 Criando índices para otimização de performance...');
  
  try {
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_contas_user_id ON contas(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_contas_tipo ON contas(tipo)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_contas_status ON contas(status)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_contas_data_vencimento ON contas(data_vencimento)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_faturas_user_id ON faturas(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_faturas_status ON faturas(status)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_faturas_contato_id ON faturas(contato_id)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_contatos_user_id ON contatos(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_contatos_tipo ON contatos(tipo)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_fluxo_caixa_user_id ON fluxo_caixa(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_fluxo_caixa_data ON fluxo_caixa(data)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_conciliacoes_user_id ON conciliacoes(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_conciliacoes_status ON conciliacoes(status)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_subscriptions_plan_id ON subscriptions(plan_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_subscription_payments_subscription_id ON subscription_payments(subscription_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_subscription_payments_status ON subscription_payments(status)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_tickets_user_id ON tickets(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_tickets_priority ON tickets(priority)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_tickets_category_id ON tickets(category_id)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_ticket_messages_ticket_id ON ticket_messages(ticket_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_ticket_messages_user_id ON ticket_messages(user_id)`);
    
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read)`);
    
    console.log('✅ Índices criados com sucesso!');
    console.log('🎉 Otimização de performance concluída!');
  } catch (error) {
    console.error('Erro ao criar índices:', error);
    throw error;
  }
}

addIndices()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error('Falha na criação de índices:', error);
    process.exit(1);
  });
