import { getWebSocketManager } from '../websocket';
import type { NotificationMessage } from '../websocket';
import { db } from '../db';
import { contas } from '@shared/schema';
import { and, eq, lte, gte } from 'drizzle-orm';

export class NotificationService {
  static sendNotification(userId: string, notification: Omit<NotificationMessage, 'timestamp'>) {
    const wsManager = getWebSocketManager();
    wsManager.sendToUser(userId, {
      ...notification,
      timestamp: new Date(),
    });
  }

  static async checkVencimentosProximos(userId: string): Promise<void> {
    const hoje = new Date();
    const em3Dias = new Date();
    em3Dias.setDate(hoje.getDate() + 3);

    const contasVencendo = await db.select().from(contas)
      .where(
        and(
          eq(contas.userId, userId),
          eq(contas.status, 'pendente'),
          gte(contas.dataVencimento, hoje),
          lte(contas.dataVencimento, em3Dias)
        )
      );

    if (contasVencendo.length > 0) {
      this.sendNotification(userId, {
        type: 'alert',
        title: 'Contas vencendo em breve',
        message: `Você tem ${contasVencendo.length} conta(s) vencendo nos próximos 3 dias`,
        severity: 'warning',
        data: { contas: contasVencendo },
      });
    }
  }

  static async checkContasVencidas(userId: string): Promise<void> {
    const hoje = new Date();

    const contasVencidas = await db.select().from(contas)
      .where(
        and(
          eq(contas.userId, userId),
          eq(contas.status, 'pendente'),
          lte(contas.dataVencimento, hoje)
        )
      );

    if (contasVencidas.length > 0) {
      this.sendNotification(userId, {
        type: 'alert',
        title: 'Contas vencidas',
        message: `Você tem ${contasVencidas.length} conta(s) vencida(s)`,
        severity: 'error',
        data: { contas: contasVencidas },
      });
    }
  }

  static async checkAll(userId: string): Promise<void> {
    await Promise.all([
      this.checkVencimentosProximos(userId),
      this.checkContasVencidas(userId),
    ]);
  }
}

export async function startNotificationScheduler() {
  const INTERVAL = 60 * 60 * 1000;

  setInterval(async () => {
    try {
      const allUsers = await db.query.users.findMany({
        where: (users, { eq }) => eq(users.isActive, true),
      });

      for (const user of allUsers) {
        await NotificationService.checkAll(user.id);
      }
    } catch (error) {
      console.error('Erro no agendador de notificações:', error);
    }
  }, INTERVAL);

  console.log('Agendador de notificações iniciado');
}
