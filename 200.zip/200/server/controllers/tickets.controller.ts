import { Response } from "express";
import { storage } from "../db-storage";

export const getCategories = async (req: any, res: Response) => {
  try {
    const categories = await storage.getTicketCategories();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar categorias" });
  }
};

export const createCategory = async (req: any, res: Response) => {
  try {
    const category = await storage.createTicketCategory(req.body);
    res.status(201).json(category);
  } catch (error) {
    res.status(500).json({ message: "Erro ao criar categoria" });
  }
};

export const getAllTickets = async (req: any, res: Response) => {
  try {
    const tickets = await storage.getAllTickets();
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar tickets" });
  }
};

export const getUserTickets = async (req: any, res: Response) => {
  try {
    const tickets = await storage.getUserTickets(req.user.id);
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar tickets" });
  }
};

export const getTicket = async (req: any, res: Response) => {
  try {
    const ticket = await storage.getTicket(req.params.id);
    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }
    
    if (req.user.role !== "admin" && ticket.userId !== req.user.id) {
      return res.status(403).json({ message: "Acesso negado" });
    }
    
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar ticket" });
  }
};

export const createTicket = async (req: any, res: Response) => {
  try {
    const ticket = await storage.createTicket({
      ...req.body,
      userId: req.user.id,
    });
    res.status(201).json(ticket);
  } catch (error) {
    res.status(500).json({ message: "Erro ao criar ticket" });
  }
};

export const updateTicket = async (req: any, res: Response) => {
  try {
    const ticket = await storage.updateTicket(req.params.id, req.body);
    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ message: "Erro ao atualizar ticket" });
  }
};

export const closeTicket = async (req: any, res: Response) => {
  try {
    const ticket = await storage.updateTicket(req.params.id, {
      status: "closed",
      closedAt: new Date(),
      closedBy: req.user.id,
    });
    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ message: "Erro ao fechar ticket" });
  }
};

export const getTicketMessages = async (req: any, res: Response) => {
  try {
    const ticket = await storage.getTicket(req.params.ticketId);
    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }
    
    if (req.user.role !== "admin" && ticket.userId !== req.user.id) {
      return res.status(403).json({ message: "Acesso negado" });
    }
    
    const messages = await storage.getTicketMessages(req.params.ticketId);
    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: "Erro ao buscar mensagens" });
  }
};

export const createTicketMessage = async (req: any, res: Response) => {
  try {
    const ticket = await storage.getTicket(req.params.ticketId);
    if (!ticket) {
      return res.status(404).json({ message: "Ticket não encontrado" });
    }
    
    if (req.user.role !== "admin" && ticket.userId !== req.user.id) {
      return res.status(403).json({ message: "Acesso negado" });
    }
    
    const message = await storage.createTicketMessage({
      ...req.body,
      ticketId: req.params.ticketId,
      userId: req.user.id,
    });
    
    if (ticket.status === "open") {
      await storage.updateTicket(ticket.id, { status: "in_progress" });
    }
    
    res.status(201).json(message);
  } catch (error) {
    res.status(500).json({ message: "Erro ao enviar mensagem" });
  }
};
