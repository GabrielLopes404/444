import { Router } from "express";
import * as subscriptionsController from "../controllers/subscriptions.controller";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

router.get("/plans", subscriptionsController.getAllPlans);

router.get("/my-subscription", requireAuth, subscriptionsController.getUserSubscription);

router.get("/admin/all", requireAdmin, subscriptionsController.getAllSubscriptions);
router.post("/admin/plans", requireAdmin, subscriptionsController.createPlan);
router.put("/admin/plans/:id", requireAdmin, subscriptionsController.updatePlan);
router.delete("/admin/plans/:id", requireAdmin, subscriptionsController.deletePlan);

router.post("/", requireAuth, subscriptionsController.createSubscription);
router.put("/:id", requireAdmin, subscriptionsController.updateSubscription);
router.post("/:id/cancel", requireAuth, subscriptionsController.cancelSubscription);

router.get("/:subscriptionId/payments", requireAuth, subscriptionsController.getSubscriptionPayments);
router.post("/payments", requireAdmin, subscriptionsController.createPayment);

export default router;
