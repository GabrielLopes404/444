import { Router } from "express";
import * as ticketsController from "../controllers/tickets.controller";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const router = Router();

router.get("/categories", requireAuth, ticketsController.getCategories);
router.post("/categories", requireAdmin, ticketsController.createCategory);

router.get("/", requireAuth, ticketsController.getUserTickets);
router.get("/admin/all", requireAdmin, ticketsController.getAllTickets);
router.get("/:id", requireAuth, ticketsController.getTicket);
router.post("/", requireAuth, ticketsController.createTicket);
router.put("/:id", requireAuth, ticketsController.updateTicket);
router.post("/:id/close", requireAuth, ticketsController.closeTicket);

router.get("/:ticketId/messages", requireAuth, ticketsController.getTicketMessages);
router.post("/:ticketId/messages", requireAuth, ticketsController.createTicketMessage);

export default router;
